#include <FreeImage.h>
int main () { if (FREEIMAGE_MAJOR_VERSION >= 3 && FREEIMAGE_MINOR_VERSION >= 9) return 1; else return 0;} 
