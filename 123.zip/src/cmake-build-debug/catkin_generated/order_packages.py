# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = '/home/ou/workspace/ugv_ws/src'
whitelisted_packages = ''.split(';') if '' != '' else []
blacklisted_packages = ''.split(';') if '' != '' else []
underlay_workspaces = '/home/ou/workspace/ugv_ws/devel;/home/ou/workspace/ros_ws/devel;/opt/ros/melodic'.split(';') if '/home/ou/workspace/ugv_ws/devel;/home/ou/workspace/ros_ws/devel;/opt/ros/melodic' != '' else []
